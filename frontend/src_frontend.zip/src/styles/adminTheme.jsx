// import { ThemeProvider, createTheme } from "@mui/material/styles";

// const theme = createTheme({
//     palette: {
//       primary: {
//         main: "#99D4F6 ", 
//       },
//       secondary: {
//         main: "#0D2838", 
//       },
//     },
//     typography: {
//       fontFamily: "Roboto, Arial, sans-serif", 
//     },
//     shadows: [
//       "none", // No shadow
//       "0px 2px 4px rgba(0, 0, 0, 0.3)", // Light shadow
//       "0px 4px 8px rgba(0, 0, 0, 0.3)", // Medium shadow
//       "0px 8px 16px rgba(0, 0, 0, 0.3)", // Strong shadow
//     ],
//   });
  
// export default theme;